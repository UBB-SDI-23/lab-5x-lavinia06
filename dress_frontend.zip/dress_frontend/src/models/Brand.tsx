import { type } from "os";

export interface Brand {
	id?: number;
    brand_fondator: string;
    brand_name: string;
    brand_rank: string;
    nr_models: number;

}